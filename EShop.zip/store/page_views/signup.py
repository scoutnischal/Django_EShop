from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.customer_model import Customer
from django.views import View
from django.contrib.auth.hashers import make_password


# Create your views here.

class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        firstname = postData.get('firstname')
        lastname = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        # validation
        value = {
            'firstname': firstname,
            'lastname': lastname,
            'phone': phone,
            'email': email,
            'password': password,
        }
        error_msg = None
        customers = Customer(first_name=firstname,
                            last_name=lastname,
                            phone=phone,
                            email=email,
                            password=password)
        if (not customers.first_name):
            error_msg = "First Name is Required !!!"
        elif len(customers.first_name) < 3:
            error_msg = "First Name must be greater than 3 characters"
        elif (not customers.last_name):
            error_msg = "Last Name is Required !!!"
        elif len(customers.last_name) < 3:
            error_msg = "Last Name must be greater than 3 characters"
        elif (not customers.phone):
            error_msg = "Phone Numberis Required !!!"
        elif len(customers.phone) < 9:
            error_msg = "Phone Number must be 10 digit only"
        elif (not customers.email):
            error_msg = "Email is Required !!!"
        elif len(customers.email) < 5:
            error_msg = "Email must be greater than 5 characters 'example@gamil.com'"
        elif (not customers.password):
            error_msg = "Password is Required !!!"
        elif len(customers.password) < 3:
            error_msg = "Password must be greater than 6 and less than 15 numeric-characters"
        elif customers.isExit():
            error_msg = "Email Address is Already Registered..."
        elif customers.isExits():
            error_msg = "Phone Number is Alreading Registered..."

        # error_msg = self.validateCustomer(customers)
        # saving
        if not error_msg:
            customers.password = make_password(customers.password)
            print(make_password(customers.password))
            customers.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_msg,
                'values': value
            }
            return render(request, 'signup.html', data)

        # def validateCustomer(self,customer):
        #     error_msg = None

        # return error_msg



# roshan Pass:123456789