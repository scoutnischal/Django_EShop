from django.contrib import admin
from .models.product_model import Product
from .models.category_model import Category
from .models.customer_model import Customer
from .models.orders import Order

class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','category']


class AdminCategoty(admin.ModelAdmin):
    list_display = ['name']


# Register your models here.
admin.site.register(Product,AdminProduct)
admin.site.register(Category,AdminCategoty)
admin.site.register(Customer)
admin.site.register(Order)


